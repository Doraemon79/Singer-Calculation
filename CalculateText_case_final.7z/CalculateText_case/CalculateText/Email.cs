﻿using SI.Mail;
namespace CalculateText
{
    /// <summary>
    ///     Method to send the mail N.B. this should be implemented by you.
    /// </summary>
    ///
    /// <seealso cref="T:ISend"/>
    public class Email : ISend
    {
        /// <summary>
        ///     Send this message.
        /// </summary>
        ///
        /// <param name="to">       to. </param>
        /// <param name="message">  The message. </param>
        public void Send(string to, string message)
        {
           // Here is email configurations
        }
    }
}

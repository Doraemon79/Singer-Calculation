﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CalculateText
{
    /// <summary>
    ///     A calculate.
    /// </summary>
    ///
    /// <seealso cref="T:CalculateText.ICalculate"/>
    class Calculate : ICalculate
    {
        /// <summary>
        ///     instantiate theOperations class.
        /// </summary>
        private IOperations _operations = new Operations();

        /// <summary>
        ///     Function to start the stream with the file.
        /// </summary>
        ///
        /// <param name="path"> . </param>
        ///
        /// <seealso cref="M:CalculateText.ICalculate.ReadWriteFile(string)"/>
        public void ReadWriteFile(string path)
        {
            // Use StreamReader to consume the entire text file.
            using (StreamReader reader = new StreamReader(path))
            {
                string str = reader.ReadLine();

                string outPara = "";

                while (str != null)
                {
                    double total = CalculateData(str);
                    outPara += str + " " + total + " " + DateTime.Now + Environment.NewLine;
                    str = reader.ReadLine();
                }

                FileInfo f = new FileInfo(path);
                string dir = f.DirectoryName;
                //creating the output file
                File.AppendAllText(dir + "\\Output.txt", outPara);
                MessageBox.Show("Data saved in Output file");
            }
        }

        /// <summary>
        ///     Read operation and invokes the needed function.
        /// </summary>
        ///
        /// <param name="str">  . </param>
        ///
        /// <returns>
        ///     The calculated data.
        /// </returns>
        ///
        /// <seealso cref="M:CalculateText.ICalculate.CalculateData(string)"/>
        public double CalculateData(string str)
        {
            try
            {
                var listofLine = str.Split(';').ToList();
                double value = 0;
                var operation = listofLine.LastOrDefault();

                switch (operation)
                {
                    case "Addition":
                        _operations.Addition(listofLine);
                        break;
                    case "Subtraction":
                        _operations.Subtraction(listofLine);
                        break;
                    case "Multiplication":
                        _operations.Multiplication(listofLine);
                        break;
                    case "Division":
                        _operations.Division(listofLine);
                        break;
                    default:
                        MessageBox.Show("Operation not recognised", "Wrong Operation", MessageBoxButton.OK,
                            MessageBoxImage.Warning);
                        break;
                }

                value = _operations.resultPropery;
                if (value < 0)
                {
                    Email email = new Email();
                    email.Send("software@singerinstruments.com", "");
                }
                return value;

            }
            catch (Exception ex)
            {
                Email email = new Email();
                email.Send("software@singerinstruments.com", "");
                return 0;
            }
        }

    }
}

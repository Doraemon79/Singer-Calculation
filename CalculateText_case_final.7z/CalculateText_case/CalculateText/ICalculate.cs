﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateText
{
    /// <summary>
    /// Interface to Calculate
    /// </summary>
    interface ICalculate
    {
        void ReadWriteFile(string path);
        double CalculateData(string str);
        //void SendEmail(string message);

    }
}

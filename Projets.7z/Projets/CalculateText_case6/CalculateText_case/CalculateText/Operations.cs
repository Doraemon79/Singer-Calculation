﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CalculateText
{
    class Operations : IOperations
    {
        /// <summary>
        /// Property result
        /// </summary>
        public double resultPropery { get; set; }

        /// <summary>
        /// Method Subtraction
        /// </summary>
        /// <param name="inputLine"></param>
        /// <returns></returns>
        public double Subtraction(List<string> inputLine)
        {

            double firstValue = 0;
            var firstOrDefault = inputLine.FirstOrDefault();
            if (firstOrDefault != null)

                if (!double.TryParse(firstOrDefault, out firstValue))
                {
                    MessageBox.Show("Please enter a valid Number", "Wrong Value", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

            List<string> copyInput = inputLine;
            copyInput.Remove(copyInput.FirstOrDefault());
            firstValue -= Addition(copyInput);
            resultPropery = firstValue;
            return firstValue;
        }
        /// <summary>
        /// Method Addition
        /// </summary>
        /// <param name="inputLine"></param>
        /// <returns></returns>
        public double Addition(List<string> inputLine)
        {
            double value = 0;

            for (int i = 0; i < inputLine.Count - 1; i++)
            {
                double currentValue = 0;
                try
                {
                    currentValue = Convert.ToDouble(inputLine[i]);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid Number", "Wrong Value", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                value += currentValue;
            }
            resultPropery = value;
            return value;
        }

        /// <summary>
        /// Method Multiplication
        /// </summary>
        /// <param name="inputLine"></param>
        /// <returns></returns>
        public double Multiplication(List<string> inputLine)
        {
            double result = 1;

            if (ItContainsZero(inputLine))
            {
                result = 0.0;
            }
            else
            {
                for (int i = 0; i < inputLine.Count - 1; i++)
                {
                    double currentValue = 0;
                    try
                    {
                        currentValue = Convert.ToDouble(inputLine[i]);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Please enter a valid Number", "Wrong Value", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    result *= currentValue;
                }
            }

            resultPropery = result;
            return result;
        }

        /// <summary>
        /// Method Division
        /// </summary>
        /// <param name="inputLine"></param>
        /// <returns></returns>
        public double Division(List<string> inputLine)
        {
            double firstValue;
            double result;

            if (!double.TryParse(inputLine.FirstOrDefault(), out firstValue))
            {
                MessageBox.Show("Please enter a valid Number", "Wrong Value", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            if (firstValue != 0)
            {
                List<string> copyInput = inputLine;
                copyInput.Remove(copyInput.LastOrDefault());
                copyInput.Remove(copyInput.FirstOrDefault());
                copyInput.Add("");
                var secondOperand = Multiplication(copyInput);
                result = firstValue / secondOperand;
            }
            else
            {
                result = 0.0;
            }
            resultPropery = result;
            return result;
        }

        /// <summary>
        /// Check it contains a "0"
        /// </summary>
        /// <param name="inputLine"></param>
        /// <returns></returns>
        public bool ItContainsZero(List<string> inputLine)
        {
            if (inputLine.Contains("0"))
            {
                List<string> copyInput = inputLine;
                copyInput.Remove(copyInput.LastOrDefault());

                List<double> copyInDouble = copyInput.Select(double.Parse).ToList();

                return copyInDouble.Contains(0.0);
            }
            return false;
        }
    }
}
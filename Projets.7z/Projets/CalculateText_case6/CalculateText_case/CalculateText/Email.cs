﻿using SI.Mail;
namespace CalculateText
{
    /// <summary>
    /// Method to send the mail N.B. this should be implemented by you
    /// </summary>
    public class Email : ISend
    {
        public void Send(string to, string message)
        {
           // Here is email configurations
        }
    }
}

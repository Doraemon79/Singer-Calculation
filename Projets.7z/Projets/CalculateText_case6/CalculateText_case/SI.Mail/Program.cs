﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SI.Mail
{
    /// <summary>
    ///  Dummy class for Mail
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}

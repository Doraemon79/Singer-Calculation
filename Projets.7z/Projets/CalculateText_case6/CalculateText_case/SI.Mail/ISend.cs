﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SI.Mail
{
    /// <summary>
    /// Dummy method to simulate sendmail
    /// </summary>
    public interface ISend
    {
        void Send(string to, string message);
    }
}

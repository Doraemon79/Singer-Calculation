﻿using System;
using System.IO;
using System.Windows;

namespace CalculateText
{
    class Calculate :ICalculate
    {
        public void ReadWriteFile(string path)
        {
            // Use StreamReader to consume the entire text file.
            using (StreamReader reader = new StreamReader(path))
            {
                string str = reader.ReadLine();

                string outPara = "";

                while (str != null)
                {
                    double total = CalculateData(str);
                    outPara += str + " " + total + " " + DateTime.Now + Environment.NewLine;
                    str = reader.ReadLine();
                }

                FileInfo f = new FileInfo(path);
                string dir = f.DirectoryName;
                
                File.AppendAllText(dir + "\\Output.txt", outPara);
                MessageBox.Show("Data saved in Output file");
            }
        }
        
        public double CalculateData(string str)
        {
            try
            {
                string[] data = str.Split(';');
                string chk = data[data.Length - 1];
                double value = 0;

                for (int i = 0; i < data.Length - 1; i++)
                {
                    double rowValue; 
                    double.TryParse(data[i], out rowValue);

                    if (chk == "Addition")
                    {
                        value += rowValue;
                    }
                    else if (chk == "Subtraction")
                    {
                        value = CommonCalculation(i, value, rowValue);
                    }
                    else if (chk == "Multiplication")
                    {
                        if (i == 0)
                        {
                            value = 1;
                        }

                        value *= rowValue;
                    }
                    else if (chk == "Division")
                    {
                        value = CommonCalculation(i, value, rowValue);
                    }
                }
                
                if (value <= 0)
                {
                    SendEmail("Total = 0 so sending email...!!!");
                }

                return value;
            }
            catch(Exception ex)
            {
                SendEmail(ex.Message);
                return 0;
            }
        }

        private static double CommonCalculation(int i, double value, double rowValue)
        {
            if (i == 0)
            {
                value = rowValue;
            }
            else
            {
                value /= rowValue;
            }

            return value;
        }

        public void SendEmail(string message)
        {
            //code to send email....
            MessageBox.Show(message);
        }

    }
}

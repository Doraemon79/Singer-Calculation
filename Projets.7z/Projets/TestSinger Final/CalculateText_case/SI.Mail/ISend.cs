﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SI.Mail
{
    /// <summary>
    ///     Interface for send.
    /// </summary>
    public interface ISend
    {
        /// <summary>
        ///     Send this message.
        /// </summary>
        ///
        /// <param name="to">       to. </param>
        /// <param name="message">  The message. </param>
        void Send(string to, string message);
    }
}

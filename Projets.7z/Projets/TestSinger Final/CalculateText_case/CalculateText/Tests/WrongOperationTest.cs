﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace CalculateText.Tests
{
    [TestFixture]
    public class WrongOperationTest
    {

        [Test]
        public void ShouldAddTwoNumbers()
        {
            ICalculate sut = new Calculate();
            int expectedResult = sut.Add(7, 8);
            Assert.That(expectedResult, Is.EqualTo(15));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateText
{
    public interface IOperations
    {


        double Subtraction(List<string> inputLine);

        double Addition(List<string> inputLine);

        double Multiplication(List<string> inputLine);

        double Division(List<string> inputLine);

        bool ItContainsZero(List<string> inputLine);

       double resultPropery { get; set; }
    }
}

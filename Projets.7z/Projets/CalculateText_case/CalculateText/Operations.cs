﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateText
{
    class Operations : IOperations
    {
        public double resultPropery { get; set; }

        public Operations() {

        }

        public double Subtraction(List<string> inputLine)
        {
            double firstValue;
            double.TryParse(inputLine.FirstOrDefault().ToString(), out firstValue);

            List<string> copyInput = inputLine;
            copyInput.Remove(copyInput.FirstOrDefault());
            firstValue -= Addition(copyInput);
            resultPropery = firstValue;
            return firstValue;
        }

        public double Addition(List<string> inputLine)
        {
            double currentValue = 0;
            double value = 0;

            for (int i = 0; i < inputLine.Count - 1; i++)
            {
                double.TryParse(inputLine.FirstOrDefault().ToString(), out currentValue);
                value += currentValue;
            }
            resultPropery = value;
            return value;
        }

        public double Multiplication(List<string> inputLine)
        {
            double result = 1;

            if (ItContainsZero(inputLine))
            {
                result = 0.0;
            }
            else
            {
                List<string> copyInput = inputLine;
                //     copyInput.Remove(copyInput.LastOrDefault());

                for (int i = 0; i < inputLine.Count - 1; i++)
                {
                    double.TryParse(inputLine.FirstOrDefault().ToString(), out result);
                    result *= result;
                }

            }
            resultPropery = result;
            return result;


        }


        public double Division(List<string> inputLine)
        {
            double firstValue;
            double result = 0.0;
            double secondOperand;

            double.TryParse(inputLine.FirstOrDefault().ToString(), out firstValue);
            if (firstValue != 0)
            {
                List<string> copyInput = inputLine;
                copyInput.Remove(copyInput.LastOrDefault());
                copyInput.Remove(copyInput.FirstOrDefault());
                secondOperand = Multiplication(copyInput);
                //     if (secondOperand == 0.0)
                //        sendmail:
                result = firstValue / secondOperand;
            }
            else
            {
                result = 0.0;

            }
            resultPropery = result;
            return result;
        }


        public bool ItContainsZero(List<string> inputLine)
        {
            List<string> copyInput = inputLine;
            copyInput.Remove(copyInput.LastOrDefault());

            List<double> copyInDouble = copyInput.Select(x => double.Parse(x)).ToList();


            return copyInDouble.Contains(0.0);
        }

    }
}
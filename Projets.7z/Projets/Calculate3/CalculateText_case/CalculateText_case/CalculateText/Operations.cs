﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateText
{
    class Operations : IOperations
    {
        public double resultPropery { get; set; }

        public double Subtraction(List<string> inputLine)
        {
            double firstValue = 0;
            var firstOrDefault = inputLine.FirstOrDefault();
            if (firstOrDefault != null)
                double.TryParse(firstOrDefault, out firstValue);

            List<string> copyInput = inputLine;
            copyInput.Remove(copyInput.FirstOrDefault());
            firstValue -= Addition(copyInput);
            resultPropery = firstValue;
            return firstValue;
        }

        public double Addition(List<string> inputLine)
        {
            double value = 0;

            for (int i = 0; i < inputLine.Count - 1; i++)
            {
                var currentValue = Convert.ToDouble(inputLine[i]);
                value += currentValue;
            }
            resultPropery = value;
            return value;
        }

        public double Multiplication(List<string> inputLine)
        {
            double result = 1;

            if (ItContainsZero(inputLine))
            {
                result = 0.0;
            }
            else
            {
                for (int i = 0; i < inputLine.Count - 1; i++)
                {
                    var currentValue = Convert.ToDouble(inputLine[i]);
                    result *= currentValue;
                }
            }
            
            resultPropery = result;
            return result;
        }


        public double Division(List<string> inputLine)
        {
            double firstValue;
            double result;

            double.TryParse(inputLine.FirstOrDefault(), out firstValue);
            if (firstValue != 0)
            {
                List<string> copyInput = inputLine;
                copyInput.Remove(copyInput.LastOrDefault());
                copyInput.Remove(copyInput.FirstOrDefault());
                copyInput.Add("");
                var secondOperand = Multiplication(copyInput);
                result = firstValue / secondOperand;
            }
            else
            {
                result = 0.0;
            }
            resultPropery = result;
            return result;
        }


        public bool ItContainsZero(List<string> inputLine)
        {
            if (inputLine.Contains("0"))
            {
                List<string> copyInput = inputLine;
                copyInput.Remove(copyInput.LastOrDefault());

                List<double> copyInDouble = copyInput.Select(double.Parse).ToList();

                return copyInDouble.Contains(0.0);
            }
            return false;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CalculateText
{
    class Calculate :ICalculate
    {

        private IOperations _operations = new Operations();

        public void ReadWriteFile(string path)
        {
            // Use StreamReader to consume the entire text file.
            using (StreamReader reader = new StreamReader(path))
            {
                string str = reader.ReadLine();

                string outPara = "";

                while (str != null)
                {
                    double total = CalculateData(str);
                    outPara += str + " " + total + " " + DateTime.Now + Environment.NewLine;
                    str = reader.ReadLine();
                }

                FileInfo f = new FileInfo(path);
                string dir = f.DirectoryName;
                //creating the output file
                File.AppendAllText(dir + "\\Output.txt", outPara);
                MessageBox.Show("Data saved in Output file");
            }
        }


        public double CalculateData(string str)
        {
            try
            {
                var listofLine = str.Split(';').ToList();

                double value = 0;

                var operation=listofLine.LastOrDefault();

                switch (operation)
                {
                    case "Addition":
                      _operations.Addition(listofLine);
                        break;
                    case "Subtraction":
                        _operations.Subtraction(listofLine);
                        break;
                    case "Multiplication":
                        _operations.Multiplication(listofLine);
                        break;
                    case "Division":
                       _operations.Division(listofLine);
                        break;
                default:
                        MessageBox.Show("Operation not recognised", "Wrong Operation", MessageBoxButton.OK,
                            MessageBoxImage.Warning);
                        break;
                }

                //for (int i = 0; i < data.Length - 1; i++)
                //{
                //    double rowValue;
                //    double.TryParse(data[i].ToString(), out rowValue);

                //    if (chk == "Addition")
                //    {
                //        value += rowValue;
                //    }
                //    else if (chk == "Subtraction")
                //    {
                //        value -= rowValue;
                //    }
                //    else if (chk == "Multiplication")
                //    {
                //        if (value == 0)
                //            value = 1;
                //        value *= rowValue;
                //    }
                //    else if (chk == "Division")
                //    {
                //        if (value == 0)
                //            value = 1;
                //        value /= rowValue;
                //    }
                //     }
                //if (value == 0)
                //    SendEmail("mail sent. result is"+value);

                value = _operations.resultPropery;
                return value;
            }
            catch(Exception ex)
            {
                SendEmail(ex.Message);
                return 0;
            }
        }

        public void SendEmail(string message)
        {
            //code to send email....
            MessageBox.Show(message);
        }

    }
}

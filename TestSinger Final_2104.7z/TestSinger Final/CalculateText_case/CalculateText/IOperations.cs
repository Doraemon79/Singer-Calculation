﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateText
{
    /// <summary>
    ///     Interface to Operations.
    /// </summary>
    public interface IOperations
    {
        /// <summary>
        /// Method Subtraction
        /// </summary>
        /// <param name="inputLine"></param>
        /// <returns></returns>
        double Subtraction(List<string> inputLine);

        /// <summary>
        ///     Method Addition.
        /// </summary>
        ///
        /// <param name="inputLine">    . </param>
        ///
        /// <returns>
        ///     A double.
        /// </returns>
        double Addition(List<string> inputLine);

        /// <summary>
        ///     Method Multiplication.
        /// </summary>
        ///
        /// <param name="inputLine">    . </param>
        ///
        /// <returns>
        ///     A double.
        /// </returns>
        double Multiplication(List<string> inputLine);

        /// <summary>
        ///     Method Division.
        /// </summary>
        ///
        /// <param name="inputLine">    . </param>
        ///
        /// <returns>
        ///     A double.
        /// </returns>
        double Division(List<string> inputLine);

        /// <summary>
        ///     Check it contains a "0".
        /// </summary>
        ///
        /// <param name="inputLine">    . </param>
        ///
        /// <returns>
        ///     true if it succeeds, false if it fails.
        /// </returns>
        bool ItContainsZero(List<string> inputLine);

        /// <summary>
        ///  Property for result.
        /// </summary>
        ///
        /// <value>
        ///  The result propery.
        /// </value>
        double resultPropery { get; set; }
    }
}

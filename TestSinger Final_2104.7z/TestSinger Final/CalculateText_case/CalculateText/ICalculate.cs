﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateText
{
    /// <summary>
    ///     Interface to Calculate.
    /// </summary>
    public interface ICalculate
    {
        /// <summary>
        ///     Reads write file.
        /// </summary>
        ///
        /// <param name="path"> Full pathname of the file. </param>
        void ReadWriteFile(string path);

        /// <summary>
        ///     Calculates the data.
        /// </summary>
        ///
        /// <param name="str">  The string. </param>
        ///
        /// <returns>
        ///     The calculated data.
        /// </returns>
        double CalculateData(string str);


    }
}

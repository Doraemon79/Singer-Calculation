﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SI.Mail
{
    /// <summary>
    ///  Dummy class for Mail
    /// </summary>
    class Program
    {
        /// <summary>
        ///     Main entry-point for this application.
        /// </summary>
        ///
        /// <param name="args"> Array of command-line argument strings. </param>
        static void Main(string[] args)
        {
        }
    }
}

﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateText.Tests
{


    [TestFixture]
    public class TestClass
    {


        [Test]
        public void When_Result_Is_Negative()
        {
            string wrongstring = "0;-1;0;Addition";
            ICalculate sut = new Calculate();
            double res = sut.CalculateData(wrongstring);
            // TODO: Add your test code here
            Assert.AreEqual(-1, res);
        }

        [Test]
        public void When_Operation_Not_Exist()
        {
            string wrongstring = "0;0;1;Addiction";
            ICalculate sut = new Calculate();
            double res = sut.CalculateData(wrongstring);
            // TODO: Add your test code here
            Assert.AreEqual(0, res);
        }


        [Test]
        public void When_number_Not_Exist()
        {
            string wrongstring = "0;null;1;Addition";
            ICalculate sut = new Calculate();
            double res = sut.CalculateData(wrongstring);
            // TODO: Add your test code here
            Assert.AreEqual(1, res);
        }


    }
}

﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests1
{
    [TestFixture]
    public class TestClass

    {
        [Test]
        public void TestMethod()
        {
            string WrongString = "1;1;Edition";
Ical
            double expectedResult = SUT.CalculateData(WrongString);
            Assert.AreEqual(expectedResult, 0);
        }
    }
}
